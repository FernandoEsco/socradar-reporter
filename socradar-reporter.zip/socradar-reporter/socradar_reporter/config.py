"""Carga de configuración desde variables de entorno (y un archivo .env opcional)."""

from __future__ import annotations

import os
from dataclasses import dataclass

try:  # python-dotenv es opcional
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover
    load_dotenv = None


class ConfigError(RuntimeError):
    """Falta una variable de configuración obligatoria."""


@dataclass(frozen=True)
class Config:
    api_key: str
    company_id: str
    base_url: str = "https://platform.socradar.com/api"
    timeout: int = 30


def cargar_config(company_id: str | None = None) -> Config:
    """Lee la configuración. El company ID pasado por CLI tiene prioridad sobre el entorno."""
    if load_dotenv is not None:
        load_dotenv()

    api_key = os.getenv("SOCRADAR_API_KEY", "").strip()
    cid = (company_id or os.getenv("SOCRADAR_COMPANY_ID", "")).strip()

    faltantes = [n for n, v in (("SOCRADAR_API_KEY", api_key), ("SOCRADAR_COMPANY_ID", cid)) if not v]
    if faltantes:
        raise ConfigError(
            "Faltan variables de configuración: " + ", ".join(faltantes)
            + ". Copia .env.example a .env y complétalo (o expórtalas en tu terminal)."
        )

    return Config(
        api_key=api_key,
        company_id=cid,
        base_url=os.getenv("SOCRADAR_BASE_URL", Config.base_url).rstrip("/"),
        timeout=int(os.getenv("SOCRADAR_TIMEOUT", Config.timeout)),
    )
