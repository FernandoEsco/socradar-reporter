"""Cálculo y parseo de fechas compartido por todos los reportes."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta


@dataclass(frozen=True)
class RangoFechas:
    inicio: date
    fin: date

    @property
    def inicio_str(self) -> str:
        return self.inicio.isoformat()

    @property
    def fin_str(self) -> str:
        return self.fin.isoformat()

    def contiene(self, d: date) -> bool:
        return self.inicio <= d <= self.fin

    def __str__(self) -> str:
        return f"{self.inicio_str} a {self.fin_str}"


def rango_ultimos_dias(dias: int = 7, hoy: date | None = None) -> RangoFechas:
    """Últimos `dias` días completos, terminando ayer (el día actual aún no cierra).

    Con dias=7 y hoy=2026-10-01 → 2026-09-24 a 2026-09-30.
    """
    if dias < 1:
        raise ValueError("dias debe ser >= 1")
    fin = (hoy or date.today()) - timedelta(days=1)
    return RangoFechas(inicio=fin - timedelta(days=dias - 1), fin=fin)


def rango_explicito(inicio: str, fin: str) -> RangoFechas:
    """Construye un rango a partir de fechas YYYY-MM-DD."""
    d_inicio, d_fin = date.fromisoformat(inicio), date.fromisoformat(fin)
    if d_inicio > d_fin:
        raise ValueError("La fecha de inicio es posterior a la de fin")
    return RangoFechas(d_inicio, d_fin)


def parsear_fecha(valor: object) -> date | None:
    """Extrae la fecha de un valor tipo '2026-08-23T19:55:44.26', '2026-08-23 10:00:00' o '2026-08-23'."""
    if not isinstance(valor, str) or not valor.strip():
        return None
    texto = valor.strip().replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(texto).date()
    except ValueError:
        try:
            return date.fromisoformat(texto[:10])
        except ValueError:
            return None
