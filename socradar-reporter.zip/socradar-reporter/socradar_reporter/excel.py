"""Exportación de reportes a Excel con formato legible."""

from __future__ import annotations

import re
from pathlib import Path

import pandas as pd
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

from .reportes.base import Reporte

_ENCABEZADO_FILL = PatternFill("solid", fgColor="1F3864")
_ENCABEZADO_FONT = Font(bold=True, color="FFFFFF")
_LINK_FONT = Font(color="0563C1", underline="single")
_INVALIDOS_HOJA = re.compile(r"[\[\]:*?/\\]")


def nombre_hoja(nombre: str, usados: set[str]) -> str:
    """Nombre de hoja válido para Excel (máx. 31 caracteres, sin caracteres prohibidos, único)."""
    base = _INVALIDOS_HOJA.sub("_", nombre).strip() or "Hoja"
    candidato, n = base[:31], 2
    while candidato.lower() in usados:
        sufijo = f" ({n})"
        candidato, n = base[: 31 - len(sufijo)] + sufijo, n + 1
    usados.add(candidato.lower())
    return candidato


def slug(texto: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", texto).strip("_").lower()


def exportar(reporte: Reporte, carpeta: Path, etiqueta: str | None = None) -> Path:
    """Escribe el reporte en `carpeta` y devuelve la ruta del archivo."""
    carpeta.mkdir(parents=True, exist_ok=True)
    partes = [reporte.slug, slug(etiqueta) if etiqueta else None,
              reporte.rango.inicio_str, reporte.rango.fin_str]
    ruta = carpeta / ("_".join(p for p in partes if p) + ".xlsx")

    usados: set[str] = set()
    with pd.ExcelWriter(ruta, engine="openpyxl") as writer:
        hojas = reporte.hojas or {"Sin resultados": pd.DataFrame(columns=reporte.columnas)}
        for nombre, df in hojas.items():
            hoja = nombre_hoja(nombre, usados)
            visibles = df.drop(columns=[c for c in df.columns if c.startswith("_")])
            visibles.to_excel(writer, sheet_name=hoja, index=False)
            ws = writer.sheets[hoja]

            # Hipervínculos: columna "_link_<Columna>" → enlace sobre <Columna>
            for col_link in (c for c in df.columns if c.startswith("_link_")):
                destino = col_link.removeprefix("_link_")
                if destino not in visibles.columns:
                    continue
                letra = get_column_letter(visibles.columns.get_loc(destino) + 1)
                for i, url in enumerate(df[col_link], start=2):
                    if isinstance(url, str) and url.startswith(("http://", "https://")):
                        ws[f"{letra}{i}"].hyperlink = url
                        ws[f"{letra}{i}"].font = _LINK_FONT

            _dar_formato(ws, visibles)
    return ruta


def _dar_formato(ws, df: pd.DataFrame) -> None:
    for celda in ws[1]:
        celda.fill, celda.font = _ENCABEZADO_FILL, _ENCABEZADO_FONT
    ws.freeze_panes = "A2"
    if ws.max_row > 1:
        ws.auto_filter.ref = ws.dimensions
    for idx, col in enumerate(df.columns, start=1):
        largo = max([len(str(col))] + [len(str(v)) for v in df[col].head(500)])
        ws.column_dimensions[get_column_letter(idx)].width = min(max(largo + 2, 10), 60)
