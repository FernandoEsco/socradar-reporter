"""SOCRadar Reporter: genera reportes en Excel a partir de la API de SOCRadar."""

__version__ = "1.0.0"
