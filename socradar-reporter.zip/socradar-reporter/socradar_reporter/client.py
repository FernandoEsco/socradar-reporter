"""Cliente HTTP mínimo para la API de SOCRadar.

- Reutiliza una sola sesión con reintentos automáticos ante 429/5xx.
- Aplica timeout a todas las peticiones.
- Nunca incluye la API key en los mensajes de error (la URL con ?key= no se imprime).
"""

from __future__ import annotations

import logging
from typing import Any

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .config import Config

log = logging.getLogger(__name__)


class SOCRadarError(RuntimeError):
    """Error al consultar la API de SOCRadar."""


class SOCRadarClient:
    def __init__(self, config: Config, session: requests.Session | None = None) -> None:
        self.config = config
        self.session = session or self._crear_sesion()

    @staticmethod
    def _crear_sesion() -> requests.Session:
        retry = Retry(
            total=3,
            backoff_factor=2,  # 2s, 4s, 8s
            status_forcelist=(429, 500, 502, 503, 504),
            allowed_methods=("GET",),
            respect_retry_after_header=True,
        )
        session = requests.Session()
        session.mount("https://", HTTPAdapter(max_retries=retry))
        session.headers.update({"Accept": "application/json", "User-Agent": "socradar-reporter"})
        return session

    def get(self, ruta: str, params: dict[str, Any] | None = None) -> Any:
        """GET a `{base_url}/{ruta}` añadiendo la API key. Devuelve el JSON decodificado."""
        url = f"{self.config.base_url}/{ruta.lstrip('/')}"
        query = {"key": self.config.api_key, **(params or {})}
        log.debug("GET %s params=%s", url, {k: v for k, v in query.items() if k != "key"})

        try:
            resp = self.session.get(url, params=query, timeout=self.config.timeout)
        except requests.RequestException as exc:
            # str(exc) puede contener la URL completa con la key: no se propaga.
            raise SOCRadarError(f"No se pudo conectar con {url} ({type(exc).__name__})") from None

        if resp.status_code != 200:
            detalle = resp.text[:300].replace(self.config.api_key, "***")
            raise SOCRadarError(f"HTTP {resp.status_code} en {url}: {detalle}")

        try:
            return resp.json()
        except ValueError:
            raise SOCRadarError(f"La respuesta de {url} no es un JSON válido") from None
