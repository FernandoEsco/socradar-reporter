"""Interfaz de línea de comandos."""

from __future__ import annotations

import argparse
import logging
import sys
import time
from pathlib import Path

from . import __version__
from .client import SOCRadarClient, SOCRadarError
from .config import ConfigError, cargar_config
from .excel import exportar
from .fechas import rango_explicito, rango_ultimos_dias
from .reportes import REPORTES

log = logging.getLogger("socradar_reporter")


def construir_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="socradar-reporter",
        description="Genera reportes de Threat Intelligence en Excel a partir de la API de SOCRadar.",
    )
    p.add_argument("-r", "--reportes", nargs="+", choices=[*REPORTES, "all"], default=["all"],
                   help="reportes a generar (por defecto: all)")
    p.add_argument("-d", "--dias", type=int, default=7,
                   help="días completos hacia atrás, terminando ayer (por defecto: 7)")
    p.add_argument("--desde", metavar="YYYY-MM-DD", help="fecha de inicio (requiere --hasta)")
    p.add_argument("--hasta", metavar="YYYY-MM-DD", help="fecha de fin (requiere --desde)")
    p.add_argument("-o", "--salida", type=Path, default=Path("reportes"),
                   help="carpeta de salida (por defecto: ./reportes)")
    p.add_argument("-e", "--etiqueta", help="etiqueta opcional para el nombre del archivo")
    p.add_argument("-c", "--company-id", help="sobrescribe SOCRADAR_COMPANY_ID")
    p.add_argument("--espera", type=float, default=1.0,
                   help="segundos entre llamadas para respetar el rate limit (por defecto: 1)")
    p.add_argument("-v", "--verbose", action="store_true", help="muestra detalle de depuración")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return p


def main(argv: list[str] | None = None) -> int:
    args = construir_parser().parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format="%(levelname)-7s %(message)s")
    logging.getLogger("urllib3").setLevel(logging.WARNING)  # sus logs incluirían la URL con la key

    try:
        if bool(args.desde) != bool(args.hasta):
            raise ValueError("--desde y --hasta deben usarse juntos")
        rango = rango_explicito(args.desde, args.hasta) if args.desde else rango_ultimos_dias(args.dias)
        config = cargar_config(args.company_id)
    except (ConfigError, ValueError) as exc:
        log.error("%s", exc)
        return 2

    seleccion = list(REPORTES) if "all" in args.reportes else list(dict.fromkeys(args.reportes))
    client = SOCRadarClient(config)
    log.info("Periodo: %s | Reportes: %s", rango, ", ".join(seleccion))

    resultados: list[tuple[str, str]] = []
    for i, nombre in enumerate(seleccion):
        if i and args.espera > 0:
            time.sleep(args.espera)
        modulo = REPORTES[nombre]
        try:
            reporte = modulo.generar(client, rango)
            ruta = exportar(reporte, args.salida, args.etiqueta)
            resultados.append((modulo.TITULO, f"OK  {reporte.total:>5} registros → {ruta}"))
        except (SOCRadarError, ValueError) as exc:
            resultados.append((modulo.TITULO, f"ERROR  {exc}"))

    print("\n=== RESUMEN ===")
    for titulo, estado in resultados:
        print(f"{titulo:<24} {estado}")
    return 1 if any("ERROR" in e for _, e in resultados) else 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
