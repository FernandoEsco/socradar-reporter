"""Botnet: credenciales robadas por infostealers y vendidas en mercados de botnets."""

from __future__ import annotations

import logging

import pandas as pd

from ..client import SOCRadarClient
from ..fechas import RangoFechas, parsear_fecha
from .base import Reporte, extraer_lista

log = logging.getLogger(__name__)

TITULO = "Botnet"
COLUMNAS = ["Fecha", "Usuario", "URL"]


def generar(client: SOCRadarClient, rango: RangoFechas) -> Reporte:
    data = client.get(
        f"leaks/company/{client.config.company_id}/latest",
        {"leak_type": "BOTNET MARKET", "start_date": rango.inicio_str, "end_date": rango.fin_str},
    )
    registros = extraer_lista(data, ("data",), ("data", "data"))

    filas = []
    for reg in registros:
        fecha = parsear_fecha(reg.get("discovery_date"))
        filas.append({
            "Fecha": fecha.isoformat() if fecha else "No disponible",
            "Usuario": reg.get("user") or "",
            "URL": reg.get("url") or "",
        })

    # Antes, si la API cambiaba los nombres de campo, el Excel salía vacío sin aviso.
    if registros and all(not f["Usuario"] and not f["URL"] for f in filas):
        log.warning("Botnet: %d registros sin 'user' ni 'url'. Campos recibidos: %s",
                    len(registros), sorted(registros[0].keys()))

    df = pd.DataFrame(filas, columns=COLUMNAS)
    reporte = Reporte(TITULO, "botnet", rango, COLUMNAS)
    if not df.empty:
        reporte.hojas["Botnet"] = df.sort_values("Fecha", ascending=False, ignore_index=True)
    return reporte
