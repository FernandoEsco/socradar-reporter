"""Impersonating Domains: dominios que imitan a la marca (typosquatting, phishing).

El endpoint no acepta filtro de fechas, así que el filtrado por `discoveryDate`
se hace localmente sobre la respuesta.
"""

from __future__ import annotations

import pandas as pd

from ..client import SOCRadarClient
from ..fechas import RangoFechas, parsear_fecha
from .base import Reporte, extraer_lista

TITULO = "Impersonating Domains"
COLUMNAS = ["Fecha", "Dominio", "Phishing Score", "Estado del sitio", "DNS MX", "Takedown"]


def generar(client: SOCRadarClient, rango: RangoFechas) -> Reporte:
    data = client.get(f"company/{client.config.company_id}/brand-protection/impersonating-domains/v2")

    filas = []
    for item in extraer_lista(data, ("data", "data"), ("data",)):
        fecha = parsear_fecha(item.get("discoveryDate"))
        if fecha is None or not rango.contiene(fecha):
            continue
        filas.append({
            "Fecha": fecha.isoformat(),
            "Dominio": item.get("impersonating_domain") or "",
            "Phishing Score": item.get("phishingScore", ""),
            "Estado del sitio": item.get("websiteStatus") or "",
            "DNS MX": item.get("dnsMxRecord") or "NA",
            "Takedown": item.get("takedownProgress") or "NA",
        })

    df = pd.DataFrame(filas, columns=COLUMNAS)
    reporte = Reporte(TITULO, "impersonating_domains", rango, COLUMNAS)
    if not df.empty:
        reporte.hojas["Dominios"] = df.sort_values("Fecha", ascending=False, ignore_index=True)
    return reporte
