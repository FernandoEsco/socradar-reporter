"""Impersonating Accounts: perfiles en redes sociales que suplantan a la marca.

Genera una hoja por plataforma; el nombre de la cuenta es un hipervínculo al perfil.
La columna "Severidad" queda vacía a propósito para que el analista la clasifique.
"""

from __future__ import annotations

from collections import defaultdict

import pandas as pd

from ..client import SOCRadarClient
from ..fechas import RangoFechas, parsear_fecha
from .base import Reporte, extraer_lista

TITULO = "Impersonating Accounts"
COLUMNAS = ["Fecha", "Severidad", "Cuenta", "Status"]


def generar(client: SOCRadarClient, rango: RangoFechas) -> Reporte:
    data = client.get(
        f"company/{client.config.company_id}/brand-protection/impersonating-accounts/v2",
        {"startDate": rango.inicio_str, "endDate": rango.fin_str},
    )

    por_plataforma: dict[str, list[dict]] = defaultdict(list)
    for item in extraer_lista(data, ("data", "data"), ("data",)):
        fecha = parsear_fecha(item.get("discoveryDate"))
        por_plataforma[item.get("platform") or "Desconocida"].append({
            "Fecha": fecha.isoformat() if fecha else "No disponible",
            "Severidad": "",
            "Cuenta": item.get("account") or "",
            "Status": item.get("status") or "",
            "_link_Cuenta": item.get("url") or "",
        })

    reporte = Reporte(TITULO, "impersonating_accounts", rango, COLUMNAS)
    for plataforma in sorted(por_plataforma):
        df = pd.DataFrame(por_plataforma[plataforma])
        reporte.hojas[plataforma] = df.sort_values("Fecha", ascending=False, ignore_index=True)
    return reporte
