"""Registro de reportes disponibles. Para añadir uno nuevo basta con crear el módulo
con una función `generar(client, rango) -> Reporte` y registrarlo aquí."""

from . import botnet, impersonating_accounts, impersonating_domains, pii_exposure

REPORTES = {
    "impersonating-accounts": impersonating_accounts,
    "botnet": botnet,
    "pii-exposure": pii_exposure,
    "impersonating-domains": impersonating_domains,
}
