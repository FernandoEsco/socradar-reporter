"""Tipos comunes a todos los reportes."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import pandas as pd

from ..fechas import RangoFechas


@dataclass
class Reporte:
    titulo: str
    slug: str
    rango: RangoFechas
    columnas: list[str]
    hojas: dict[str, pd.DataFrame] = field(default_factory=dict)

    @property
    def total(self) -> int:
        return sum(len(df) for df in self.hojas.values())


def extraer_lista(data: Any, *rutas: tuple[str, ...]) -> list[dict]:
    """Devuelve la primera lista encontrada siguiendo las rutas dadas dentro del JSON.

    La API no es uniforme: algunos endpoints responden {"data": [...]} y otros
    {"data": {"data": [...]}}. Si ninguna ruta coincide se lanza un error claro en
    vez de generar un Excel vacío silenciosamente.
    """
    for ruta in rutas:
        nodo = data
        for clave in ruta:
            nodo = nodo.get(clave) if isinstance(nodo, dict) else None
        if isinstance(nodo, list):
            return [r for r in nodo if isinstance(r, dict)]
    raise ValueError(f"Estructura de respuesta inesperada (se buscó en: {list(rutas)})")
