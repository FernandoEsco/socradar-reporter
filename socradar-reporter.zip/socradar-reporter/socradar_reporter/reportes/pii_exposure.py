"""PII Exposure: credenciales de empleados expuestas en filtraciones."""

from __future__ import annotations

import pandas as pd

from ..client import SOCRadarClient
from ..fechas import RangoFechas, parsear_fecha
from .base import Reporte, extraer_lista

TITULO = "PII Exposure"
COLUMNAS = ["Fecha", "Email"]


def generar(client: SOCRadarClient, rango: RangoFechas) -> Reporte:
    data = client.get(
        f"leaks/company/{client.config.company_id}/latest",
        {"start_date": rango.inicio_str, "end_date": rango.fin_str},
    )
    filas = []
    for reg in extraer_lista(data, ("data",), ("data", "data")):
        history = (reg.get("extra_info") or {}).get("history") or []
        fecha = parsear_fecha(history[0].get("date")) if history and isinstance(history[0], dict) else None
        filas.append({
            "Fecha": fecha.isoformat() if fecha else "No disponible",
            "Email": reg.get("email") or "No disponible",
        })

    df = pd.DataFrame(filas, columns=COLUMNAS)
    if not df.empty:
        df = df.drop_duplicates().sort_values("Fecha", ascending=False, ignore_index=True)

    reporte = Reporte(TITULO, "pii_exposure", rango, COLUMNAS)
    if not df.empty:
        reporte.hojas["PII Exposure"] = df
    return reporte
