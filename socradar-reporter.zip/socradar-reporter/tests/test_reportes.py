"""Pruebas sin red: la API se simula con un cliente falso y datos ficticios."""

from datetime import date

import pytest
from openpyxl import load_workbook

from socradar_reporter.cli import main
from socradar_reporter.client import SOCRadarClient, SOCRadarError
from socradar_reporter.config import Config, ConfigError, cargar_config
from socradar_reporter.excel import exportar, nombre_hoja
from socradar_reporter.fechas import parsear_fecha, rango_explicito, rango_ultimos_dias
from socradar_reporter.reportes import (botnet, impersonating_accounts,
                                        impersonating_domains, pii_exposure)
from socradar_reporter.reportes.base import extraer_lista

CONFIG = Config(api_key="SECRETA-123", company_id="999")
RANGO = rango_explicito("2026-09-24", "2026-09-30")


class ClienteFalso:
    def __init__(self, respuesta):
        self.config = CONFIG
        self.respuesta = respuesta
        self.llamadas = []

    def get(self, ruta, params=None):
        self.llamadas.append((ruta, params))
        return self.respuesta


# --- fechas -----------------------------------------------------------------

def test_rango_ultimos_dias_termina_ayer():
    r = rango_ultimos_dias(7, hoy=date(2026, 10, 1))
    assert (r.inicio_str, r.fin_str) == ("2026-09-24", "2026-09-30")


@pytest.mark.parametrize("valor,esperado", [
    ("2026-08-23T19:55:44.268275", date(2026, 8, 23)),
    ("2026-08-23 10:00:00", date(2026, 8, 23)),
    ("2026-08-23", date(2026, 8, 23)),
    ("2026-08-23T10:00:00Z", date(2026, 8, 23)),
    ("", None), (None, None), ("basura", None),
])
def test_parsear_fecha(valor, esperado):
    assert parsear_fecha(valor) == esperado


def test_rango_invertido_falla():
    with pytest.raises(ValueError):
        rango_explicito("2026-09-30", "2026-09-01")


# --- configuración ------------------------------------------------------------

def test_config_falla_sin_variables(monkeypatch):
    monkeypatch.delenv("SOCRADAR_API_KEY", raising=False)
    monkeypatch.delenv("SOCRADAR_COMPANY_ID", raising=False)
    monkeypatch.setattr("socradar_reporter.config.load_dotenv", None)
    with pytest.raises(ConfigError, match="SOCRADAR_API_KEY"):
        cargar_config()


# --- reportes -----------------------------------------------------------------

def test_pii_exposure_extrae_fecha_y_email_y_deduplica():
    data = {"data": [
        {"email": "ana@ejemplo.com", "extra_info": {"history": [{"date": "2026-09-25 08:00:00"}]}},
        {"email": "ana@ejemplo.com", "extra_info": {"history": [{"date": "2026-09-25 08:00:00"}]}},
        {"email": "luis@ejemplo.com", "extra_info": {}},
    ]}
    rep = pii_exposure.generar(ClienteFalso(data), RANGO)
    df = rep.hojas["PII Exposure"]
    assert rep.total == 2
    assert set(df["Fecha"]) == {"2026-09-25", "No disponible"}


def test_botnet_envia_leak_type():
    cli = ClienteFalso({"data": [{"discovery_date": "2026-09-26", "user": "u1", "url": "https://x.test"}]})
    rep = botnet.generar(cli, RANGO)
    assert cli.llamadas[0][1]["leak_type"] == "BOTNET MARKET"
    assert rep.hojas["Botnet"].iloc[0]["Usuario"] == "u1"


def test_botnet_avisa_si_cambian_los_campos(caplog):
    rep = botnet.generar(ClienteFalso({"data": [{"otro_campo": 1}]}), RANGO)
    assert rep.total == 1
    assert "otro_campo" in caplog.text


def test_impersonating_accounts_agrupa_por_plataforma():
    data = {"data": {"data": [
        {"platform": "Instagram", "account": "@falsa1", "url": "https://instagram.test/falsa1",
         "discoveryDate": "2026-09-25T10:00:00", "status": "OPEN"},
        {"platform": "X", "account": "@falsa2", "discoveryDate": "2026-09-26T10:00:00"},
        {"account": "@sinplataforma"},
    ]}}
    rep = impersonating_accounts.generar(ClienteFalso(data), RANGO)
    assert set(rep.hojas) == {"Instagram", "X", "Desconocida"}


def test_impersonating_domains_filtra_por_rango():
    data = {"data": {"data": [
        {"impersonating_domain": "dentro.test", "discoveryDate": "2026-09-24T00:00:00"},
        {"impersonating_domain": "fuera.test", "discoveryDate": "2026-09-01T00:00:00"},
        {"impersonating_domain": "sin-fecha.test"},
    ]}}
    rep = impersonating_domains.generar(ClienteFalso(data), RANGO)
    df = rep.hojas["Dominios"]
    assert list(df["Dominio"]) == ["dentro.test"]
    assert df.iloc[0]["DNS MX"] == "NA"


def test_estructura_inesperada_da_error_claro():
    with pytest.raises(ValueError, match="inesperada"):
        extraer_lista({"error": "algo"}, ("data",))


# --- Excel --------------------------------------------------------------------

def test_exportar_con_hipervinculo_y_sin_columnas_internas(tmp_path):
    data = {"data": {"data": [{"platform": "Instagram", "account": "@falsa",
                               "url": "https://instagram.test/falsa", "discoveryDate": "2026-09-25"}]}}
    rep = impersonating_accounts.generar(ClienteFalso(data), RANGO)
    ruta = exportar(rep, tmp_path, etiqueta="Mi Empresa")
    assert ruta.name == "impersonating_accounts_mi_empresa_2026-09-24_2026-09-30.xlsx"

    ws = load_workbook(ruta)["Instagram"]
    assert [c.value for c in ws[1]] == ["Fecha", "Severidad", "Cuenta", "Status"]
    assert ws["C2"].hyperlink.target == "https://instagram.test/falsa"


def test_exportar_reporte_vacio(tmp_path):
    rep = botnet.generar(ClienteFalso({"data": []}), RANGO)
    wb = load_workbook(exportar(rep, tmp_path))
    assert wb.sheetnames == ["Sin resultados"]


def test_nombre_hoja_valido_y_unico():
    usados = set()
    assert nombre_hoja("a/b:c" + "x" * 40, usados) == ("a_b_c" + "x" * 40)[:31]
    assert nombre_hoja("Hoja", usados) == "Hoja"
    assert nombre_hoja("hoja", usados) == "hoja (2)"


# --- cliente: la API key nunca aparece en errores -----------------------------

class _Resp:
    status_code = 401
    text = "invalid key SECRETA-123"


class _Sesion:
    def get(self, *a, **k):
        return _Resp()


def test_error_http_no_filtra_la_key():
    with pytest.raises(SOCRadarError) as exc:
        SOCRadarClient(CONFIG, session=_Sesion()).get("ruta")
    assert "SECRETA-123" not in str(exc.value)


# --- CLI ----------------------------------------------------------------------

def test_cli_sin_config_devuelve_2(monkeypatch):
    monkeypatch.delenv("SOCRADAR_API_KEY", raising=False)
    monkeypatch.delenv("SOCRADAR_COMPANY_ID", raising=False)
    monkeypatch.setattr("socradar_reporter.config.load_dotenv", None)
    assert main(["-r", "botnet"]) == 2


def test_cli_genera_archivos(monkeypatch, tmp_path):
    monkeypatch.setenv("SOCRADAR_API_KEY", "x")
    monkeypatch.setenv("SOCRADAR_COMPANY_ID", "1")
    monkeypatch.setattr(SOCRadarClient, "get", lambda self, ruta, params=None: {"data": []})
    codigo = main(["-r", "botnet", "pii-exposure", "-o", str(tmp_path), "--espera", "0"])
    assert codigo == 0
    assert len(list(tmp_path.glob("*.xlsx"))) == 2
